## ✨ *Zero ERP: un progetto costruito un mattone alla volta*

C’è chi scrive codice per necessità.  
C’è chi scrive codice per mestiere.  
E poi c’è chi lo fa per costruire una casa, una casa in cui ogni abitante si sentirà a proprio agio come avvolto in un abbraccio.    
Una casa dove ogni campo è una porta, ogni tabella è una stanza, ogni processo è un percorso pensato con cura.

**Zero ERP nasce così.** 
Non da una moda, non da un’azienda, ma da una lunga storia , fatta di trent’anni di lavoro, ascolto, rispetto per la complessità dei sistemi e delle persone.

Per anni, quel server che tanti chiamavano *AS/400*, per me era una casa viva che ogni giorno ho cercato di rendere più accogliente, moderna, confortevole. 
L’ho costruita mattone dopo mattone, giorno dopo giorno.
Oggi quel palazzo non c’è più, ma la conoscenza, lo stile, la visione sono rimasti.  
E ora possono vivere in modo nuovo: libero, aperto,condiviso

**Zero ERP.**  
Un progetto che vuole unire ciò che è solido con ciò che è essenziale.  
Un ERP che ha imparato a eliminare il superfluo, per far spazio alla chiarezza.  
Una piattaforma che non nasce solo per fatturare, ma per durare, essere capita e, se possibile, anche amata.

Il tempo, gli eventi  che portano a  svolte impreviste  della Vita , mi hanno fatto comprendere nuovi valori e oggi so con certezza che è tempo per costruire con verità.
E questo progetto non è solo la mia libertà, ma anche la certezza che renderà più liberi tutti gli abitanti di questa casa.

A chi vorrà contribuire, imparare, proporre:  
Benvenuto a casa. 

Questo non è solo software, è un’idea che vi regalerà tempo per le persone e le cose  che amate.  
È un’idea che si può toccare.

---


---
{% include-markdown "signature-core.md" %}
