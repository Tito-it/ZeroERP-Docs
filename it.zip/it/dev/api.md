## API

**Da fare**
---


---
{% include-markdown "signature-core.md" %}
