---
description: Sviluppo idee
---

# Zero project promemoria sviluppo idee

## 📝 Promemoria Completo delle Considerazioni sul Progetto Zero ERP

### 💡 Concetti Generali e Motivazioni

* **Nome del Progetto:** "Zero" rappresenta una ripartenza personale e professionale.
* **Finalità:** ERP multiservizi modulare e flessibile.

### 🗃️ Aspetti Chiave e Decisioni Prese

* **Anagrafica Generale:** Centralizzata e obbligatoria per tutti i soggetti con almeno un ruolo definito.
* **Ruoli Specifici:** Tabelle dedicate per informazioni specifiche (cliente, fornitore, distributore, gestore software unico obbligatorio).
* **Centralizzazione Indirizzi:** Gestione obbligatoria di indirizzi con tipologie specifiche (residenza, fornitura, spedizione, domicilio fiscale).
* **Storicizzazione Dati:** Tutte le informazioni critiche (es. dati societari come capitale sociale, forma giuridica, PEC) storicizzate in tabelle dedicate.
* **Codice Fiscale Forzato:** Gestione specifica per casi particolari in cui il CF è assegnato manualmente.
* **Contatti Aziendali:** Gestione dedicata dei contatti con informazioni su ruoli aziendali e titoli per intestazione documenti.

### 🔍 Specifiche Tecniche Principali

* **Forniture:** Obbligatorie per ogni servizio (anche standard), indipendenti dai clienti.
* **Servizi:** Multisettoriali, con definizione di un servizio "default".
* **Clienti e Contratti:** Associazione chiara e storicizzata di servizi, forniture e clienti, con definizione contrattuale completa (offerte, listini, condizioni speciali).
* **Cabine REMI e POD/PDR:** Tabelle specifiche per la gestione del settore utility (gas, energia), con indirizzi ufficiali e verifiche automatiche di congruenza.
* **Distributori:** Collegati direttamente all'anagrafica generale con dati aggiuntivi (es. pronto intervento).

### 🎯 Benefici Concreti

* Centralizzazione dati e facilità gestionale.
* Chiarezza e precisione operativa.
* Compliance normativa e regolatoria (es. ARERA).
* Flessibilità e scalabilità future del sistema.

### ✅ Conclusioni Importanti

Questo promemoria raccoglie tutte le decisioni e i ragionamenti effettuati per il progetto Zero ERP e costituisce una sintesi utile per eventuali revisioni o ampliamenti futuri.

---


---
{% include-markdown "signature-core.md" %}
