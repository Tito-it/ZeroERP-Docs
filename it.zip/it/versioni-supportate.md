# Versioni supportate

| Componente   | Versione        |
|--------------|-----------------|
| Python       | 3.x             |
| Django       | 5.x             |
| PostgreSQL   | 17+             |
| Liquibase    | 4.x             |
| Vue 3        | 3.x             |
|              |                 |
| …            | …               |

---


---
{% include-markdown "signature-core.md" %}
