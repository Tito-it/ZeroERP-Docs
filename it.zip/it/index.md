# Zero ERP

Benvenuto nella documentazione del progetto **Zero ERP**!

Questa guida copre:

- Come installare e configurare l’ambiente di sviluppo
- Panoramica dell’architettura e del modello dati
- Dettagli sulle API disponibili
- Esempi di utilizzo e best practice
