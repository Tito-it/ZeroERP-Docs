# Schema `catalogo`

## 📚 Tabelle
- [articoli](tabelle/articoli.md)
- [articoli_componenti](tabelle/articoli_componenti.md)
- [unita_misura](tabelle/unita_misura.md) — * Centralizzare le **unità di misura** in un unico repository. * Fornire sia una **descrizione tecnica interna** sia una **descrizione breve** per la stampa in documenti fiscali e commerciali. * Garantire la **coerenza** tra articoli, movimenti di magazzino e righe di fattura.

## ⚙️ Funzioni

## 🔍 Views
