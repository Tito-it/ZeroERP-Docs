# 📚 Tabella `emittenti_fiscali`

## 🗂️ Campi principali
| Colonna | Tipo | Nullable | Default |
|---------|------|----------|---------|
| id | bigint | NO |  |
| uid | uuid | NO | gen_random_uuid() |
| soggetto_ruolo_id | bigint | NO |  |
| codice | character varying | NO |  |
| descrizione | character varying | NO |  |
| attivo | boolean | NO | true |
| regime_fiscale_rf | character varying | YES |  |
| esigibilita_iva_default | character | YES |  |
| split_payment_default | boolean | YES |  |
| bollo_auto | boolean | YES |  |
| bollo_soglia | numeric | YES |  |
| rounding_policy | character varying | YES |  |
| brand_meta | jsonb | NO | '{}'::jsonb |
| tx_id | uuid | YES |  |
| storicizza | boolean | NO | true |
| data_insert | timestamp with time zone | NO | now() |
| user_insert | character varying | NO | CURRENT_USER |
| data_update | timestamp with time zone | NO | now() |
| user_update | character varying | YES | CURRENT_USER |

## 🔒 Vincoli
| Tipo | Nome | Colonne |
|------|------|---------|
| CHECK | chk_emittenti_fiscali_bollo_soglia |  |
| CHECK | chk_emittenti_fiscali_codice_non_vuoto |  |
| CHECK | chk_emittenti_fiscali_esigibilita |  |
| FOREIGN KEY | fk_emittenti_fiscali_ruolo | soggetto_ruolo_id |
| PRIMARY KEY | pk_emittf | id |
| UNIQUE | uq:codice | codice |
| UNIQUE | uq_emittenti_fiscali_ruolo | soggetto_ruolo_id |
| UNIQUE | uq_emittenti_fiscali_uid | uid |

## 📑 Indici
| Nome | Definizione |
|------|-------------|
| ix_emittenti_fiscali_attivo | `CREATE INDEX ix_emittenti_fiscali_attivo ON anagrafiche.emittenti_fiscali USING btree (attivo)` |
| pk_emittf | `CREATE UNIQUE INDEX pk_emittf ON anagrafiche.emittenti_fiscali USING btree (id)` |
| uq:codice | `CREATE UNIQUE INDEX "uq:codice" ON anagrafiche.emittenti_fiscali USING btree (codice)` |
| uq_emittenti_fiscali_ruolo | `CREATE UNIQUE INDEX uq_emittenti_fiscali_ruolo ON anagrafiche.emittenti_fiscali USING btree (soggetto_ruolo_id)` |
| uq_emittenti_fiscali_uid | `CREATE UNIQUE INDEX uq_emittenti_fiscali_uid ON anagrafiche.emittenti_fiscali USING btree (uid)` |

## 🚨 Trigger
| Nome | Timing | Evento | Azione |
|------|--------|--------|--------|
| trg_a10_emittenti_fiscali_upd_protect_codice | BEFORE | UPDATE | `EXECUTE FUNCTION anagrafiche.trgfn_a10_emittenti_fiscali_protect_codice()` |
| trg_emittenti_fiscali_ins_upd_check_ruolo_emi_fis | BEFORE | INSERT | `EXECUTE FUNCTION anagrafiche.trgfn_emittenti_fiscali_ins_upd_check_ruolo_emi_fis()` |
| trg_emittenti_fiscali_ins_upd_check_ruolo_emi_fis | BEFORE | UPDATE | `EXECUTE FUNCTION anagrafiche.trgfn_emittenti_fiscali_ins_upd_check_ruolo_emi_fis()` |
| trg_emittenti_fiscali_ins_upd_gen_tx_id | BEFORE | INSERT | `EXECUTE FUNCTION dbops.trgfn_tx_id_managed()` |
| trg_emittenti_fiscali_ins_upd_gen_tx_id | BEFORE | UPDATE | `EXECUTE FUNCTION dbops.trgfn_tx_id_managed()` |
| trg_emittenti_fiscali_ins_upd_norm | BEFORE | UPDATE | `EXECUTE FUNCTION anagrafiche.trgfn_emittenti_fiscali_norm()` |
| trg_emittenti_fiscali_ins_upd_norm | BEFORE | INSERT | `EXECUTE FUNCTION anagrafiche.trgfn_emittenti_fiscali_norm()` |
| trg_upd_emittenti_fiscali_audit_data_user | BEFORE | UPDATE | `EXECUTE FUNCTION script.trgfn_upd_audit_data_user_generic()` |

---
{% include-markdown "signature-core.md" %}
