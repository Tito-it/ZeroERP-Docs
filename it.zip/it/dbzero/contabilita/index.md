# Schema `contabilita`

## 📚 Tabelle

## ⚙️ Funzioni

## 🔍 Views
