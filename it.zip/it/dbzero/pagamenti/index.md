# Schema `pagamenti`

## 📚 Tabelle
- [sepa_mandati](tabelle/sepa_mandati.md)

## ⚙️ Funzioni

## 🔍 Views
