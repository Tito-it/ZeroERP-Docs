## 📘 Documentazione Concettuale – Tabella `config.valute`

La tabella **`config.valute`** definisce le valute monetarie utilizzate in Zero ERP, fornendo i codici, i simboli e le informazioni necessarie per la gestione coerente di tutte le transazioni finanziarie.

---

### 🎯 Scopo Principale

* **Definizione delle valute**
  Elenco centralizzato di tutte le valute supportate, con codici interni e standard ISO 4217.
* **Supporto ai moduli finanziari**
  Garantisce alle aree di fatturazione, contabilità e reporting uniformità nella rappresentazione e conversione delle valute.
* **Tracciabilità e auditing**
  Memorizza informazioni di inserimento e aggiornamento per mantenere la storicità delle modifiche.

---



### 💡 Vantaggi Operativi

* **Standardizzazione**
  Consente a tutti i moduli di usare codici e simboli unificati, evitando errori di conversione.
* **Performance di ricerca**
  Indice sulla descrizione velocizza lookup e autocomplete nei form.
* **Audit completo**
  Trigger e campi utente/timestamp garantiscono piena tracciabilità delle variazioni nelle configurazioni.

---

> 🧠 **"Una tabella snella e vincolata per garantire coerenza, performance e audit nella gestione delle valute di Zero ERP."**
