# ⚙️ Procedura `proc_automations_attivo_job`

```sql
CREATE PROCEDURE proc_automations_attivo_job()
```

**Definizione completa:**

```sql
CREATE OR REPLACE PROCEDURE maintenance.proc_automations_attivo_job()
 LANGUAGE plpgsql
AS $procedure$
BEGIN
  PERFORM maintenance.fn_run_and_log(
    p_jobname  := 'automations_attivo',
    p_stepname := 'run_automations_attivo',
    p_sql      := 'SELECT dbops.fn_run_automations_attivo(''SCHEDULED'', NULL, false);',
    p_lock_key := hashtext('automations_attivo')
  );
END;
$procedure$
```

---
{% include-markdown "signature-core.md" %}
