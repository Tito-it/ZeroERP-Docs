# 📚 Tabella `preventivi_righe`

## 🗂️ Campi principali
| Colonna | Tipo | Nullable | Default |
|---------|------|----------|---------|
| id | bigint | NO |  |
| preventivo_id | bigint | NO |  |
| articolo_id | uuid | NO |  |
| descrizione | character varying | YES |  |
| unita_misura_id | integer | YES |  |
| quantita | numeric | NO |  |
| prezzo_unitario | numeric | NO |  |
| sconto_percentuale | numeric | YES | 0 |
| iva_id | integer | YES |  |
| meta | jsonb | YES | '{}'::jsonb |
| ordine | smallint | YES | 0 |
| attivo | boolean | YES | true |

## 🔒 Vincoli
| Tipo | Nome | Colonne |
|------|------|---------|
| CHECK | chk_prevrighe_quantita_prezzo |  |
| CHECK | chk_prevrighe_sconto |  |
| FOREIGN KEY | fk_prevrighe_articoli | articolo_id |
| FOREIGN KEY | fk_prevrighe_iva | iva_id |
| FOREIGN KEY | fk_prevrighe_preventivi | preventivo_id |
| FOREIGN KEY | fk_prevrighe_unita_misura | unita_misura_id |
| PRIMARY KEY | pk_preventivi_righe | id |

## 📑 Indici
| Nome | Definizione |
|------|-------------|
| ix_prevrighe_articolo | `CREATE INDEX ix_prevrighe_articolo ON vendite.preventivi_righe USING btree (articolo_id)` |
| ix_prevrighe_preventivo | `CREATE INDEX ix_prevrighe_preventivo ON vendite.preventivi_righe USING btree (preventivo_id)` |
| pk_preventivi_righe | `CREATE UNIQUE INDEX pk_preventivi_righe ON vendite.preventivi_righe USING btree (id)` |

## 🚨 Trigger
| Nome | Timing | Evento | Azione |
|------|--------|--------|--------|
| trg_chk_preventivi_righe_parent_fk_prevrighe_articoli | AFTER | INSERT | `EXECUTE FUNCTION dbops.trgfn_child_requires_active_parent('catalogo', 'articoli', 'attivo', 'articolo_id')` |
| trg_chk_preventivi_righe_parent_fk_prevrighe_articoli | AFTER | UPDATE | `EXECUTE FUNCTION dbops.trgfn_child_requires_active_parent('catalogo', 'articoli', 'attivo', 'articolo_id')` |
| trg_chk_preventivi_righe_parent_fk_prevrighe_unita_misura | AFTER | INSERT | `EXECUTE FUNCTION dbops.trgfn_child_requires_active_parent('catalogo', 'unita_misura', 'attivo', 'unita_misura_id')` |
| trg_chk_preventivi_righe_parent_fk_prevrighe_unita_misura | AFTER | UPDATE | `EXECUTE FUNCTION dbops.trgfn_child_requires_active_parent('catalogo', 'unita_misura', 'attivo', 'unita_misura_id')` |

---
{% include-markdown "signature-core.md" %}
