{% include-markdown "it/dbzero/vendite/manual/articoli_spesa.md" %}
# 📚 Tabella `articoli_spesa`

## 🗂️ Campi principali
| Colonna | Tipo | Nullable | Default |
|---------|------|----------|---------|
| id | integer | NO |  |
| codice | character varying | NO |  |
| descrizione | character varying | NO |  |
| descrizione_fattura | character varying | YES |  |
| attivo | boolean | NO | true |
| user_insert | character varying | NO | CURRENT_USER |
| user_update | character varying | YES | CURRENT_USER |
| data_insert | timestamp with time zone | NO | now() |
| data_update | timestamp with time zone | NO | now() |

## 🔒 Vincoli
| Tipo | Nome | Colonne |
|------|------|---------|
| PRIMARY KEY | pk_articoli_spesa | id |
| UNIQUE | uq_articoli_spesa_codice | codice |

## 📑 Indici
| Nome | Definizione |
|------|-------------|
| ix_articoli_spesa_codice_upper | `CREATE INDEX ix_articoli_spesa_codice_upper ON vendite.articoli_spesa USING btree (upper((codice)::text))` |
| pk_articoli_spesa | `CREATE UNIQUE INDEX pk_articoli_spesa ON vendite.articoli_spesa USING btree (id)` |
| uq_articoli_spesa_codice | `CREATE UNIQUE INDEX uq_articoli_spesa_codice ON vendite.articoli_spesa USING btree (codice)` |

## 🚨 Trigger
| Nome | Timing | Evento | Azione |
|------|--------|--------|--------|
| trg_soft_del_articoli_spesa__articoli__fk_articoli_artic_535934 | AFTER | UPDATE | `EXECUTE FUNCTION dbops.trgfn_soft_delete_cascade('catalogo', 'articoli', 'spesa_id')` |
| trg_soft_del_articoli_spesa_articoli_fk_articoli_articoli_spesa | AFTER | UPDATE | `EXECUTE FUNCTION dbops.trgfn_soft_delete_cascade('catalogo', 'articoli', 'spesa_id')` |
| trg_upd_articoli_spesa_audit_data_user | BEFORE | UPDATE | `EXECUTE FUNCTION script.trgfn_upd_audit_data_user_generic()` |

---
{% include-markdown "signature-core.md" %}
