# Schema `magazzino`

## 📚 Tabelle
- [magazzini](tabelle/magazzini.md)

## ⚙️ Funzioni
- [trgfn_a10_magazzini_protect_codice](funzioni/trgfn_a10_magazzini_protect_codice.md)
- [trgfn_magazzini_norm](funzioni/trgfn_magazzini_norm.md)

## 🔍 Views
