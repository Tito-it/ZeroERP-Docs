# Schema `public`

## 📚 Tabelle
- [version_info](manual/version_info.md)