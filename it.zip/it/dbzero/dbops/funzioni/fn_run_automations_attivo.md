# ⚙️ Funzione `fn_run_automations_attivo`

```sql
CREATE FUNCTION fn_run_automations_attivo(p_exec_mode text, p_schemas text[], p_dry_run boolean)
```

**Definizione completa:**

```sql
CREATE OR REPLACE FUNCTION dbops.fn_run_automations_attivo(p_exec_mode text, p_schemas text[], p_dry_run boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
  v_schemas text[];
  rrule record;
  rfk   record;

  exist_strat text;

  -- template (JSON con 3 nomi)
  nm_cascade text;
  nm_require text;
  nm_block   text;

  -- colonne attivo
  col_attivo_parent text;
  col_attivo_child  text;

  parent_has_attivo boolean;
  child_has_attivo  boolean;

  fk_col text;

  tname_parent_cascade text;
  tname_child_require  text;
  tname_parent_block   text;

  exists_by_name bool;
  exists_by_args bool;
BEGIN
  
  -- ======================================================================
  -- dbops.run_automations_attivo(p_exec_mode, p_schemas, p_dry_run)
  -- Applica regole ATTIVO/soft-delete su FK con ON DELETE RESTRICT:
  --   - CASO A (padre&figlio con attivo): 
  --       * padre AFTER UPDATE OF attivo → dbops.trgfn_soft_delete_cascade()
  --       * figlio CONSTRAINT DEFERRABLE → dbops.trgfn_child_requires_active_parent()
  --   - CASO B (solo padre con attivo):
  --       * padre BEFORE UPDATE OF attivo → dbops.trgfn_prevent_deactivate_if_children()
  -- Usa naming parametrico (3 template JSON: cascade/require/block).
  -- ======================================================================

  v_schemas := dbops.fn_resolve_scope(p_schemas);
  FOR rrule IN
  SELECT r.*
  FROM dbops.automation_rules_tbl r
  WHERE r.enabled
    AND r.rule_type = 'ATTIVO'
    AND (r.exec_mode = 'AUTO' OR r.exec_mode = p_exec_mode)
    AND dbops.fn_schema_in_scope(r.target_schema, v_schemas)  -- <-- r., non rrule
  ORDER BY r.priority, r.id

  LOOP
    exist_strat := COALESCE(rrule.existence_strategy,'BY_NAME');

    nm_cascade := COALESCE((rrule.name_template::jsonb)->>'cascade','trg_soft_del_{parent}_{child}_{fkcol}');
    nm_require := COALESCE((rrule.name_template::jsonb)->>'require','trg_chk_{child}_parent_{fkcol}');
    nm_block   := COALESCE((rrule.name_template::jsonb)->>'block','trg_block_deact_{parent}_{child}');

    FOR rfk IN
      SELECT
        c.oid AS conoid,
        np.nspname AS parent_schema,
        cp.relname AS parent_table,
        nc.nspname AS child_schema,
        cc.relname AS child_table,
        c.conrelid::regclass AS child_rel,
        c.confrelid::regclass AS parent_rel,
        c.conname,
        c.confdeltype
      FROM pg_constraint c
      JOIN pg_class cc ON cc.oid = c.conrelid
      JOIN pg_namespace nc ON nc.oid = cc.relnamespace
      JOIN pg_class cp ON cp.oid = c.confrelid
      JOIN pg_namespace np ON np.oid = cp.relnamespace
      WHERE c.contype='f'
        AND c.confdeltype IN ('r','a')  -- RESTRICT o NO ACTION
        AND nc.nspname <> 'storico'  -- child
        AND np.nspname <> 'storico'  -- parent (by safety)
        AND ( dbops.fn_schema_match(rrule.target_schema, nc.nspname)  )  -- child
         --   OR dbops.fn_schema_match(rrule.target_schema, np.nspname) )  -- parent
        AND dbops.fn_table_in_scope(nc.nspname, cc.relname)
         --  AND dbops.fn_table_in_scope(np.nspname, cp.relname))
        -- target_table applicata a child OPPURE parent
        AND (rrule.target_table IS NULL OR cc.relname LIKE rrule.target_table OR cp.relname LIKE rrule.target_table)
        AND NOT EXISTS (
          SELECT 1 FROM dbops.automation_fk_exclusions e
          WHERE e.parent_schema=np.nspname AND e.parent_table=cp.relname
            AND e.child_schema=nc.nspname  AND e.child_table=cc.relname
        )
    LOOP
      col_attivo_parent := dbops.fn_get_override_col(rfk.parent_schema, rfk.parent_table, 'ATTIVO_COL', 'attivo');
      col_attivo_child  := dbops.fn_get_override_col(rfk.child_schema,  rfk.child_table,  'ATTIVO_COL', 'attivo');

      SELECT dbops.fn_col_exists(rfk.parent_schema, rfk.parent_table, col_attivo_parent)
          , dbops.fn_col_exists(rfk.child_schema,  rfk.child_table,  col_attivo_child)
        INTO parent_has_attivo, child_has_attivo;

      fk_col := dbops.fn_get_child_fk_col(rfk.conoid);
    /*
      tname_parent_cascade := dbops.fn_name_from_template(nm_cascade, rfk.parent_schema, rfk.parent_table, rfk.parent_table, rfk.child_table, rfk.conname, NULL);
      tname_child_require  := dbops.fn_name_from_template(nm_require, rfk.child_schema, rfk.child_table, rfk.parent_table, rfk.child_table, rfk.conname, NULL);
      tname_parent_block   := dbops.fn_name_from_template(nm_block, rfk.parent_schema, rfk.parent_table, rfk.parent_table, rfk.child_table, rfk.conname, NULL);
    */ 

      tname_parent_cascade :=
        replace(
          dbops.fn_name_from_template(nm_cascade,
            rfk.parent_schema, rfk.parent_table,
            rfk.parent_table, rfk.child_table, rfk.conname, NULL),
          '{fkcol}', fk_col
        );

      tname_child_require :=
        replace(
          dbops.fn_name_from_template(nm_require,
            rfk.child_schema, rfk.child_table,
            rfk.parent_table, rfk.child_table, rfk.conname, NULL),
          '{fkcol}', fk_col
        );

      tname_parent_block :=
        dbops.fn_name_from_template(nm_block,
          rfk.parent_schema, rfk.parent_table,
          rfk.parent_table, rfk.child_table, rfk.conname, NULL);
    --  tname_parent_block := regexp_replace(tname_parent_block, '_{2,}', '_', 'g');
    --  tname_parent_block := regexp_replace(tname_parent_block, '^_+|_+$', '', 'g');

      -- CASO A: entrambi hanno attivo → cascade + require
      IF parent_has_attivo AND child_has_attivo THEN
        -- padre: cascade
        exists_by_name := dbops.fn_trigger_exists_by_name(rfk.parent_rel, tname_parent_cascade);
        exists_by_args := dbops.fn_trigger_exists_cascade_by_args(rfk.parent_rel, rfk.child_schema, rfk.child_table, fk_col);

        IF (exist_strat='BY_NAME'     AND NOT exists_by_name)
          OR (exist_strat='BY_FUNCTION' AND NOT exists_by_args)
          OR (exist_strat='BOTH'        AND NOT (exists_by_name OR exists_by_args)) 

        THEN
          IF p_dry_run THEN   
            PERFORM dbops.fn_audit_log_once(
                    p_function_name => 'dbops.fn_run_automations',
                    p_status        => 'DRYRUN',
                    p_rule_type     => 'ATTIVO_cascade',
                    p_exec_mode     => p_exec_mode,
                    p_parts         => ARRAY['ATTIVO_cascade'],
                    p_dry_run       => true,
                    p_params        => jsonb_build_object(
                                        'action','DRYRUN_CREATE_TRIGGER',
                                       'rule','ATTIVO_cascade',
                                        'table',rfk.parent_schema||'.'||rfk.parent_table,
                                        'name',tname_parent_cascade,'fk',fk_col
                                      ),
                    p_message       => 'TRIGGER would be created'
                  );   
          
          ELSE
            BEGIN
              EXECUTE format($f$
                CREATE TRIGGER %I
                AFTER UPDATE OF %I ON %I.%I
                FOR EACH ROW
                EXECUTE FUNCTION dbops.trgfn_soft_delete_cascade(%L,%L,%L)
              $f$, tname_parent_cascade, col_attivo_parent, rfk.parent_schema, rfk.parent_table, rfk.child_schema, rfk.child_table, fk_col);
            EXCEPTION WHEN others THEN
                
               PERFORM script.fn_log_and_raise_error(
                    'dbops',
                    'run_automations',
                    'E_ATTIVO_cascade',
                    jsonb_build_object(
                      'where','ATTIVO_cascade',
                      'table', rtab.schema_name||'.'||rtab.table_name,
                      'table',rfk.parent_schema||'.'||rfk.parent_table,
                      'error', SQLERRM
                    ) , NULL::uuid, SQLERRM
                  ); 
            
            END;
          END IF;
        END IF;

        -- figlio: require (constraint, deferrable)
        exists_by_name := dbops.fn_trigger_exists_by_name(rfk.child_rel, tname_child_require);
        exists_by_args := dbops.fn_trigger_exists_require_by_args(rfk.child_rel, rfk.parent_schema, rfk.parent_table, col_attivo_parent, fk_col);

        IF (exist_strat='BY_NAME'     AND NOT exists_by_name)
          OR (exist_strat='BY_FUNCTION' AND NOT exists_by_args)
          OR (exist_strat='BOTH'        AND NOT (exists_by_name OR exists_by_args)) 

      
        THEN
          IF p_dry_run THEN
                
            PERFORM dbops.fn_audit_log_once(
                    p_function_name => 'dbops.fn_run_automations',
                    p_status        => 'DRYRUN',
                    p_rule_type     => 'ATTIVO_require',
                    p_exec_mode     => p_exec_mode,
                    p_parts         => ARRAY['ATTIVO_require'],
                    p_dry_run       => true,
                    p_params        => jsonb_build_object(
                                        'action','DRYRUN_CREATE_TRIGGER',
                                       'rule','ATTIVO_require',
                                        'table',rfk.parent_schema||'.'||rfk.parent_table,
                                        'name',tname_parent_cascade,'fk',fk_col
                                      ),
                    p_message       => 'TRIGGER would be created'
                  ); 
          ELSE
            BEGIN
              EXECUTE format($f$
                CREATE CONSTRAINT TRIGGER %I
                AFTER INSERT OR UPDATE OF %I, %I ON %I.%I
                DEFERRABLE INITIALLY DEFERRED
                FOR EACH ROW
                EXECUTE FUNCTION dbops.trgfn_child_requires_active_parent(%L,%L,%L,%L)
              $f$, tname_child_require, col_attivo_child, fk_col, rfk.child_schema, rfk.child_table,
                  rfk.parent_schema, rfk.parent_table, col_attivo_parent, fk_col);
            EXCEPTION WHEN others THEN
             
                 PERFORM script.fn_log_and_raise_error(
                    'dbops',
                    'run_automations',
                    'E_ATTIVO_require',
                    jsonb_build_object(
                      'where','ATTIVO_require',
                      'table',rfk.parent_schema||'.'||rfk.parent_table,
                       'error', SQLERRM
                    ) , NULL::uuid, SQLERRM
                  ); 

            
            END;
          END IF;
        END IF;

      -- CASO B: solo padre ha attivo → blocco
      ELSIF parent_has_attivo AND NOT child_has_attivo THEN
        --IF (exist_strat='BY_NAME'     AND NOT dbops.fn_trigger_exists_by_name(rfk.parent_rel, tname_parent_block))
        --OR (exist_strat='BY_FUNCTION' AND NOT dbops.fn_trigger_exists_by_function(rfk.parent_rel,'dbops','trgfn_prevent_deactivate_if_children'))
        --OR (exist_strat='BOTH'        AND NOT (dbops.fn_trigger_exists_by_name(rfk.parent_rel, tname_parent_block)
        --                                  OR dbops.fn_trigger_exists_by_function(rfk.parent_rel,'dbops','trgfn_prevent_deactivate_if_children')))
        exists_by_name := dbops.fn_trigger_exists_by_name(rfk.parent_rel, tname_parent_block);
        exists_by_args := dbops.fn_trigger_exists_block_by_args(rfk.parent_rel, rfk.child_schema, rfk.child_table, fk_col);

        IF (exist_strat='BY_NAME'     AND NOT exists_by_name)
          OR (exist_strat='BY_FUNCTION' AND NOT exists_by_args)
          OR (exist_strat='BOTH'        AND NOT (exists_by_name OR exists_by_args)) 
          
        THEN
          IF p_dry_run THEN
            
             PERFORM dbops.fn_audit_log_once(
                    p_function_name => 'dbops.fn_run_automations',
                    p_status        => 'DRYRUN',
                    p_rule_type     => 'ATTIVO_block',
                    p_exec_mode     => p_exec_mode,
                    p_parts         => ARRAY['ATTIVO_block'],
                    p_dry_run       => true,
                    p_params        => jsonb_build_object(
                                        'action','DRYRUN_CREATE_TRIGGER',
                                       'rule','ATTIVO_block',
                                        'table',rfk.parent_schema||'.'||rfk.parent_table,
                                        'name',tname_parent_cascade,'fk',fk_col
                                      ),
                    p_message       => 'TRIGGER would be created'
                  ); 
          ELSE
            BEGIN
              EXECUTE format($f$
                CREATE TRIGGER %I
                BEFORE UPDATE OF %I ON %I.%I
                FOR EACH ROW
                EXECUTE FUNCTION dbops.trgfn_prevent_deactivate_if_children(%L,%L,%L)
              $f$, tname_parent_block, col_attivo_parent, rfk.parent_schema, rfk.parent_table, rfk.child_schema, rfk.child_table, fk_col);
            EXCEPTION WHEN others THEN
                  
                PERFORM script.fn_log_and_raise_error(
                    'dbops',
                    'run_automations',
                    'E_ATTIVO_block',
                    jsonb_build_object(
                      'where','ATTIVO_block',
                      'table',rfk.parent_schema||'.'||rfk.parent_table,
                      'error', SQLERRM
                    ) , NULL::uuid, SQLERRM
                  ); 
            
            END;
          END IF;
        END IF;
      END IF;

    END LOOP; -- fk
  END LOOP; -- regole ATTIVO
END;
$function$
```

---
{% include-markdown "signature-core.md" %}
