{% include-markdown "it/dbzero/dbops/manual/trgfn_soft_delete_cascade.md" %}
# ⚙️ Funzione `trgfn_soft_delete_cascade`

```sql
CREATE FUNCTION trgfn_soft_delete_cascade()
```

**Definizione completa:**

```sql
CREATE OR REPLACE FUNCTION dbops.trgfn_soft_delete_cascade()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
  DECLARE
    v_child_schema  text;
    v_child_table   text;
    v_fk_col        text;
    v_pk_col        text;     -- default 'id' se non passato
    v_parent_pk_val text;     -- valore PK del padre (estratto dal record OLD)
    v_sql           text;
  BEGIN
    -- Parametri: child_schema, child_table, fk_col [, pk_col]
    IF array_length(TG_ARGV, 1) < 3 THEN
      PERFORM script.fn_log_and_raise_error(
        'trgfn_soft_delete_cascade',
        'Argomenti insufficienti',
        'Attesi: child_schema, child_table, fk_col [, pk_col]'
      );
    END IF;

    v_child_schema := TG_ARGV[0];
    v_child_table  := TG_ARGV[1];
    v_fk_col       := TG_ARGV[2];

    IF array_length(TG_ARGV, 1) >= 4 THEN
      v_pk_col := TG_ARGV[3];
    ELSE
      v_pk_col := 'id';
      PERFORM script.fn_log_error_only(
        'trgfn_soft_delete_cascade',
        format('Usata PK di default ''id'' per %I.%I', TG_TABLE_SCHEMA, TG_TABLE_NAME),
        'Passa pk_col come 4° parametro per evitare ambiguità'
      );
    END IF;

    IF TG_OP = 'UPDATE'
      AND COALESCE(OLD.attivo, FALSE) = TRUE
      AND COALESCE(NEW.attivo, FALSE) = FALSE
    THEN
      -- Estrai il valore della PK dal record OLD in modo robusto (niente hack JSON)
      EXECUTE format('SELECT ($1).%I::text', v_pk_col)
        INTO v_parent_pk_val
        USING OLD;

      IF v_parent_pk_val IS NULL THEN
        PERFORM script.fn_log_error_only(
          'trgfn_soft_delete_cascade',
          format('PK %I nulla su %I.%I: nessun figlio aggiornato', v_pk_col, TG_TABLE_SCHEMA, TG_TABLE_NAME),
          NULL
        );
        RETURN NEW;
      END IF;

      -- Spegne i figli: attivo = FALSE (solo questo)
      v_sql := format(
        'UPDATE %I.%I SET attivo = FALSE WHERE %I = ($1)',
        v_child_schema, v_child_table, v_fk_col
      );

      BEGIN
        EXECUTE v_sql USING v_parent_pk_val;
      EXCEPTION WHEN OTHERS THEN
        PERFORM script.fn_log_and_raise_error(
          'trgfn_soft_delete_cascade',
          format('Errore soft-delete cascata su %I.%I', v_child_schema, v_child_table),
          format('SQLSTATE=%s; ERR=%s; SQL=[%s]', SQLSTATE, SQLERRM, v_sql)
        );
      END;
    END IF;

    RETURN NEW;
  END;
  $function$
```

---
{% include-markdown "signature-core.md" %}
