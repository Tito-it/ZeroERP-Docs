{% include-markdown "it/dbzero/dbops/manual/trgfn_child_requires_active_parent.md" %}
# ⚙️ Funzione `trgfn_child_requires_active_parent`

```sql
CREATE FUNCTION trgfn_child_requires_active_parent()
```

**Definizione completa:**

```sql
CREATE OR REPLACE FUNCTION dbops.trgfn_child_requires_active_parent()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
  v_parent_schema     text;
  v_parent_table      text;
  v_parent_attivo_col text;
  v_fk_col            text;
  v_parent_pk_col     text;        -- PK del padre (default 'id')
  v_fk_val_text       text;        -- valore FK dal figlio (come text)
  v_parent_pk_type    text;        -- tipo della PK del padre (per cast)
  v_sql               text;
  v_active            boolean;
BEGIN
  -- Parametri: parent_schema, parent_table, parent_attivo_col, fk_col [, parent_pk_col]
  IF array_length(TG_ARGV, 1) < 4 THEN
    PERFORM script.fn_log_and_raise_error(
      'trgfn_child_requires_active_parent',
      'Argomenti insufficienti',
      'Attesi: parent_schema, parent_table, parent_attivo_col, fk_col [, parent_pk_col]'
    );
  END IF;

  v_parent_schema     := TG_ARGV[0];
  v_parent_table      := TG_ARGV[1];
  v_parent_attivo_col := TG_ARGV[2];
  v_fk_col            := TG_ARGV[3];
  v_parent_pk_col     := COALESCE(TG_ARGV[4], 'id');

  IF TG_ARGV[4] IS NULL THEN
    PERFORM script.fn_log_error_only(
      'trgfn_child_requires_active_parent',
      format('Usata PK di default ''id'' per %I.%I', v_parent_schema, v_parent_table),
      'Passa pk_col come 5° parametro per evitare ambiguità'
    );
  END IF;

  -- Se il figlio NON è (o non resta) attivo, nessun controllo
  IF NOT (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') OR COALESCE(NEW.attivo, FALSE) IS NOT TRUE THEN
    RETURN NEW;
  END IF;

  -- Estrai in modo robusto il valore della FK dal record NEW
  EXECUTE format('SELECT ($1).%I::text', v_fk_col)
    INTO v_fk_val_text
    USING NEW;

  -- FK nulla? Non ammesso con figlio attivo
  IF v_fk_val_text IS NULL THEN
    PERFORM script.fn_log_and_raise_error(
      'trgfn_child_requires_active_parent',
      format('FK %I NULL per figlio attivo', v_fk_col),
      NULL
    );
  END IF;

  -- Ricava il tipo della PK del padre per cast corretto (uuid/bigint/…)
  SELECT a.atttypid::regtype::text
    INTO v_parent_pk_type
    FROM pg_attribute a
    JOIN pg_class c  ON c.oid = a.attrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = v_parent_schema
    AND c.relname = v_parent_table
    AND a.attname = v_parent_pk_col
    AND a.attnum > 0
    AND NOT a.attisdropped;

  IF v_parent_pk_type IS NULL THEN
    PERFORM script.fn_log_and_raise_error(
      'trgfn_child_requires_active_parent',
      'Colonna PK padre non trovata',
      format('%I.%I.%I', v_parent_schema, v_parent_table, v_parent_pk_col)
    );
  END IF;

  -- Verifica esistenza e stato del padre (cast del parametro al tipo PK)
  v_sql := format(
    'SELECT %I FROM %I.%I WHERE %I = ($1)::%s',
    v_parent_attivo_col, v_parent_schema, v_parent_table,
    v_parent_pk_col, v_parent_pk_type
  );

  BEGIN
    EXECUTE v_sql INTO v_active USING v_fk_val_text;

    IF NOT FOUND THEN
      PERFORM script.fn_log_and_raise_error(
        'trgfn_child_requires_active_parent',
        format('Padre %.% non trovato (%I=%s)', v_parent_schema, v_parent_table, v_parent_pk_col, v_fk_val_text),
        'foreign_key_violation'
      );
    END IF;

    IF NOT COALESCE(v_active, FALSE) THEN
      PERFORM script.fn_log_and_raise_error(
        'trgfn_child_requires_active_parent',
        format('Padre %.% non attivo (%I=%s): figlio attivo non consentito', v_parent_schema, v_parent_table, v_parent_pk_col, v_fk_val_text),
        'check_violation'
      );
    END IF;

  EXCEPTION
    WHEN undefined_column OR undefined_table THEN
      PERFORM script.fn_log_and_raise_error(
        'trgfn_child_requires_active_parent',
        'Configurazione errata: tabella/colonna non esistente',
        format('parent=%.% fk_col=%I', v_parent_schema||'.'||v_parent_table, v_fk_col)
      );
  END;

  RETURN NEW;
END;
$function$
```

---
{% include-markdown "signature-core.md" %}
