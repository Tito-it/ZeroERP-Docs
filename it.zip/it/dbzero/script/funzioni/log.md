# ⚙️ Funzione `log`

```sql
CREATE FUNCTION log(p_area text, p_function_name text, p_error_code text, p_context jsonb, p_tx_id uuid, VARIADIC p_valori text[])
```

**Definizione completa:**

```sql
CREATE OR REPLACE FUNCTION script.log(p_area text, p_function_name text, p_error_code text, p_context jsonb, p_tx_id uuid, VARIADIC p_valori text[])
 RETURNS void
 LANGUAGE sql
AS $function$
    --  Completa con VARIADIC: 6 argomenti
  SELECT script.fn_log_error_only($1,$2,$3,$4,$5, VARIADIC $6)
$function$
```

---
{% include-markdown "signature-core.md" %}
