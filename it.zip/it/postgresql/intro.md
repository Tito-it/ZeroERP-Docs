## 📘 Introduzione a PostgreSQL

Zero ERP utilizza PostgreSQL, un database relazionale open-source potente e altamente estensibile, riconosciuto per robustezza, scalabilità e aderenza agli standard SQL. La scelta di PostgreSQL risponde alle esigenze specifiche del progetto Zero ERP, dove è fondamentale garantire integrità dei dati, elevate prestazioni e flessibilità nello sviluppo e nella gestione.

### Perché PostgreSQL?

* **Integrità e Affidabilità**: PostgreSQL garantisce consistenza e durabilità dei dati attraverso avanzati meccanismi di transazione e controllo dei vincoli.
* **Estendibilità**: Supporta numerose estensioni come `dblink` per comunicazioni inter-database e `pgcrypto` per sicurezza e crittografia.
* **Performance e Scalabilità**: Offre eccellenti prestazioni anche con dataset molto grandi e carichi di lavoro complessi, grazie a strumenti come gli indici avanzati e il query planner intelligente.
* **Community e Supporto**: Ampia comunità di utenti e sviluppatori, che offre documentazione estesa e risorse utili per supporto e manutenzione.

### Struttura della documentazione del Database

Questa sezione della documentazione include:

* **Installazione e configurazione iniziale**: dettagli operativi per configurare PostgreSQL in modo ottimale per Zero ERP.
* **Estensioni utilizzate**: panoramica delle estensioni PostgreSQL adottate, come `dblink`, `pgcrypto`, e altre.
* **Parametri personalizzati (GUC)**: guida alla definizione, utilizzo e gestione dei parametri applicativi personalizzati per adattare il database alle specifiche esigenze di Zero ERP.

Seguendo questa documentazione sarà possibile gestire al meglio PostgreSQL all’interno di Zero ERP, sfruttandone pienamente le potenzialità e garantendo stabilità e affidabilità al sistema.

---


---
{% include-markdown "signature-core.md" %}
